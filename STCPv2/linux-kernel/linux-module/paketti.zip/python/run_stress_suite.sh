#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
PYTHON="${PYTHON:-python3}"

cd "$SCRIPT_DIR"

echo "=== STCP throughput: 4 clients / 25 s ==="
"$PYTHON" ./stcp_stress.py \
    --mode throughput \
    --pipeline 1 \
    --port 7777 \
    --clients 4 \
    --payload 262144 \
    --duration 25 \
    --json result-throughput-4.json

echo
echo "=== STCP mixed: 8 clients / 30 s ==="
"$PYTHON" ./stcp_stress.py \
    --mode mixed \
    --port 7778 \
    --reconnect-every 128 \
    --clients 8 \
    --payload 262144 \
    --duration 30 \
    --json result-mixed-8.json

echo
echo "=== STCP churn: 16 clients / 30 s ==="
"$PYTHON" ./stcp_stress.py \
    --mode churn \
    --port 7779 \
    --clients 16 \
    --payload 4096 \
    --duration 30 \
    --json result-churn-16.json
