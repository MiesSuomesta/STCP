savedcmd_src/panic.o := aarch64-linux-gnu-gcc -Wp,-MMD,src/.panic.o.d -nostdinc -I/home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include -I/home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/generated -I/home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include -I/home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include -I/home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/uapi -I/home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/generated/uapi -I/home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi -I/home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/generated/uapi -include /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/compiler-version.h -include /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/kconfig.h -include /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/compiler_types.h -D__KERNEL__ -mlittle-endian -DCC_USING_PATCHABLE_FUNCTION_ENTRY -DKASAN_SHADOW_SCALE_SHIFT= -std=gnu11 -fshort-wchar -funsigned-char -fno-common -fno-PIE -fno-strict-aliasing -mgeneral-regs-only -DCONFIG_CC_HAS_K_CONSTRAINT=1 -Wno-psabi -mabi=lp64 -fno-asynchronous-unwind-tables -fno-unwind-tables -mbranch-protection=pac-ret -Wa,-march=armv8.5-a -DARM64_ASM_ARCH='"armv8.5-a"' -DKASAN_SHADOW_SCALE_SHIFT= -fno-delete-null-pointer-checks -O2 -fno-allow-store-data-races -fstack-protector-strong -fno-omit-frame-pointer -fno-optimize-sibling-calls -ftrivial-auto-var-init=zero -fno-stack-clash-protection -fpatchable-function-entry=4,2 -fmin-function-alignment=8 -fstrict-flex-arrays=3 -fno-strict-overflow -fno-stack-check -fconserve-stack -fno-builtin-wcslen -Wall -Wextra -Wundef -Werror=implicit-function-declaration -Werror=implicit-int -Werror=return-type -Werror=strict-prototypes -Wno-format-security -Wno-trigraphs -Wno-frame-address -Wno-address-of-packed-member -Wmissing-declarations -Wmissing-prototypes -Wframe-larger-than=2048 -Wno-main -Wno-dangling-pointer -Wvla-larger-than=1 -Wno-pointer-sign -Wcast-function-type -Wno-array-bounds -Wno-stringop-overflow -Wno-alloc-size-larger-than -Wimplicit-fallthrough=5 -Werror=date-time -Werror=incompatible-pointer-types -Werror=designated-init -Wenum-conversion -Wunused -Wno-unused-but-set-variable -Wno-unused-const-variable -Wno-packed-not-aligned -Wno-format-overflow -Wno-format-truncation -Wno-stringop-truncation -Wno-override-init -Wno-missing-field-initializers -Wno-type-limits -Wno-shift-negative-value -Wno-maybe-uninitialized -Wno-sign-compare -Wno-unused-parameter -mstack-protector-guard=sysreg -mstack-protector-guard-reg=sp_el0 -mstack-protector-guard-offset=1504 -I././include  -DMODULE  -DKBUILD_BASENAME='"panic"' -DKBUILD_MODNAME='"stcp"' -D__KBUILD_MODNAME=kmod_stcp -c -o src/panic.o src/panic.c  

source_src/panic.o := src/panic.c

deps_src/panic.o := \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/compiler-version.h \
    $(wildcard include/config/CC_VERSION_TEXT) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/kconfig.h \
    $(wildcard include/config/CPU_BIG_ENDIAN) \
    $(wildcard include/config/BOOGER) \
    $(wildcard include/config/FOO) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/compiler_types.h \
    $(wildcard include/config/DEBUG_INFO_BTF) \
    $(wildcard include/config/PAHOLE_HAS_BTF_TAG) \
    $(wildcard include/config/FUNCTION_ALIGNMENT) \
    $(wildcard include/config/CC_HAS_SANE_FUNCTION_ALIGNMENT) \
    $(wildcard include/config/X86_64) \
    $(wildcard include/config/ARM64) \
    $(wildcard include/config/LD_DEAD_CODE_DATA_ELIMINATION) \
    $(wildcard include/config/LTO_CLANG) \
    $(wildcard include/config/HAVE_ARCH_COMPILER_H) \
    $(wildcard include/config/KCSAN) \
    $(wildcard include/config/CC_HAS_ASSUME) \
    $(wildcard include/config/CC_HAS_COUNTED_BY) \
    $(wildcard include/config/CC_HAS_MULTIDIMENSIONAL_NONSTRING) \
    $(wildcard include/config/UBSAN_INTEGER_WRAP) \
    $(wildcard include/config/CFI) \
    $(wildcard include/config/ARCH_USES_CFI_GENERIC_LLVM_PASS) \
    $(wildcard include/config/CC_HAS_ASM_INLINE) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/compiler_attributes.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/compiler-gcc.h \
    $(wildcard include/config/ARCH_USE_BUILTIN_BSWAP) \
    $(wildcard include/config/SHADOW_CALL_STACK) \
    $(wildcard include/config/KCOV) \
    $(wildcard include/config/CC_HAS_TYPEOF_UNQUAL) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/asm/compiler.h \
    $(wildcard include/config/ARM64_PTR_AUTH_KERNEL) \
    $(wildcard include/config/ARM64_PTR_AUTH) \
    $(wildcard include/config/BUILTIN_RETURN_ADDRESS_STRIPS_PAC) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/bug.h \
    $(wildcard include/config/GENERIC_BUG) \
    $(wildcard include/config/PRINTK) \
    $(wildcard include/config/BUG_ON_DATA_CORRUPTION) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/asm/bug.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/stringify.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/asm/asm-bug.h \
    $(wildcard include/config/DEBUG_BUGVERBOSE) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/asm/brk-imm.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/bug.h \
    $(wildcard include/config/BUG) \
    $(wildcard include/config/GENERIC_BUG_RELATIVE_POINTERS) \
    $(wildcard include/config/SMP) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/compiler.h \
    $(wildcard include/config/TRACE_BRANCH_PROFILING) \
    $(wildcard include/config/PROFILE_ALL_BRANCHES) \
    $(wildcard include/config/OBJTOOL) \
    $(wildcard include/config/64BIT) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/asm/rwonce.h \
    $(wildcard include/config/LTO) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/rwonce.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/kasan-checks.h \
    $(wildcard include/config/KASAN_GENERIC) \
    $(wildcard include/config/KASAN_SW_TAGS) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/types.h \
    $(wildcard include/config/HAVE_UID16) \
    $(wildcard include/config/UID16) \
    $(wildcard include/config/ARCH_DMA_ADDR_T_64BIT) \
    $(wildcard include/config/PHYS_ADDR_T_64BIT) \
    $(wildcard include/config/ARCH_32BIT_USTAT_F_TINODE) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/linux/types.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/generated/uapi/asm/types.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/asm-generic/types.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/int-ll64.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/asm-generic/int-ll64.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/uapi/asm/bitsperlong.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/bitsperlong.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/asm-generic/bitsperlong.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/linux/posix_types.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/stddef.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/linux/stddef.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/uapi/asm/posix_types.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/asm-generic/posix_types.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/kcsan-checks.h \
    $(wildcard include/config/KCSAN_WEAK_MEMORY) \
    $(wildcard include/config/KCSAN_IGNORE_ATOMICS) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/instrumentation.h \
    $(wildcard include/config/NOINSTR_VALIDATION) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/once_lite.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/panic.h \
    $(wildcard include/config/PANIC_TIMEOUT) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/stdarg.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/printk.h \
    $(wildcard include/config/MESSAGE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_QUIET) \
    $(wildcard include/config/EARLY_PRINTK) \
    $(wildcard include/config/PRINTK_INDEX) \
    $(wildcard include/config/DYNAMIC_DEBUG) \
    $(wildcard include/config/DYNAMIC_DEBUG_CORE) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/init.h \
    $(wildcard include/config/MEMORY_HOTPLUG) \
    $(wildcard include/config/HAVE_ARCH_PREL32_RELOCATIONS) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/build_bug.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/kern_levels.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/linkage.h \
    $(wildcard include/config/ARCH_USE_SYM_ANNOTATIONS) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/export.h \
    $(wildcard include/config/MODVERSIONS) \
    $(wildcard include/config/GENDWARFKSYMS) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/asm/linkage.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/ratelimit_types.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/bits.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/vdso/bits.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/vdso/const.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/linux/const.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/linux/bits.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/overflow.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/limits.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/linux/limits.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/vdso/limits.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/const.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/linux/param.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/uapi/asm/param.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/param.h \
    $(wildcard include/config/HZ) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/asm-generic/param.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/spinlock_types_raw.h \
    $(wildcard include/config/DEBUG_SPINLOCK) \
    $(wildcard include/config/DEBUG_LOCK_ALLOC) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/asm/spinlock_types.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/qspinlock_types.h \
    $(wildcard include/config/NR_CPUS) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/qrwlock_types.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/uapi/asm/byteorder.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/byteorder/little_endian.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/linux/byteorder/little_endian.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/swab.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/linux/swab.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/generated/uapi/asm/swab.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/asm-generic/swab.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/byteorder/generic.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/lockdep_types.h \
    $(wildcard include/config/PROVE_RAW_LOCK_NESTING) \
    $(wildcard include/config/LOCKDEP) \
    $(wildcard include/config/LOCK_STAT) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/kernel.h \
    $(wildcard include/config/PREEMPT_VOLUNTARY_BUILD) \
    $(wildcard include/config/PREEMPT_DYNAMIC) \
    $(wildcard include/config/HAVE_PREEMPT_DYNAMIC_CALL) \
    $(wildcard include/config/HAVE_PREEMPT_DYNAMIC_KEY) \
    $(wildcard include/config/PREEMPT_) \
    $(wildcard include/config/DEBUG_ATOMIC_SLEEP) \
    $(wildcard include/config/MMU) \
    $(wildcard include/config/PROVE_LOCKING) \
    $(wildcard include/config/DYNAMIC_FTRACE) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/align.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/vdso/align.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/array_size.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/container_of.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/bitops.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/typecheck.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/linux/kernel.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/linux/sysinfo.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/bitops/generic-non-atomic.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/asm/barrier.h \
    $(wildcard include/config/ARM64_PSEUDO_NMI) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/asm/alternative-macros.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/asm/cpucaps.h \
    $(wildcard include/config/ARM64_PAN) \
    $(wildcard include/config/ARM64_EPAN) \
    $(wildcard include/config/ARM64_SVE) \
    $(wildcard include/config/ARM64_SME) \
    $(wildcard include/config/ARM64_CNP) \
    $(wildcard include/config/ARM64_MTE) \
    $(wildcard include/config/ARM64_BTI) \
    $(wildcard include/config/ARM64_TLB_RANGE) \
    $(wildcard include/config/ARM64_POE) \
    $(wildcard include/config/ARM64_GCS) \
    $(wildcard include/config/ARM64_HAFT) \
    $(wildcard include/config/UNMAP_KERNEL_AT_EL0) \
    $(wildcard include/config/ARM64_ERRATUM_843419) \
    $(wildcard include/config/ARM64_ERRATUM_1742098) \
    $(wildcard include/config/ARM64_ERRATUM_2645198) \
    $(wildcard include/config/ARM64_ERRATUM_2658417) \
    $(wildcard include/config/CAVIUM_ERRATUM_23154) \
    $(wildcard include/config/NVIDIA_CARMEL_CNP_ERRATUM) \
    $(wildcard include/config/ARM64_WORKAROUND_REPEAT_TLBI) \
    $(wildcard include/config/ARM64_ERRATUM_3194386) \
    $(wildcard include/config/ARM64_ERRATUM_4193714) \
    $(wildcard include/config/HW_PERF_EVENTS) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/generated/asm/cpucap-defs.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/asm/insn-def.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/barrier.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/asm/bitops.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/bitops/builtin-__ffs.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/bitops/builtin-ffs.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/bitops/builtin-__fls.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/bitops/builtin-fls.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/bitops/ffz.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/bitops/fls64.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/bitops/sched.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/bitops/hweight.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/bitops/arch_hweight.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/bitops/const_hweight.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/bitops/atomic.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/atomic.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/asm/atomic.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/asm/cmpxchg.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/asm/lse.h \
    $(wildcard include/config/ARM64_LSE_ATOMICS) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/asm/atomic_ll_sc.h \
    $(wildcard include/config/CC_HAS_K_CONSTRAINT) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/asm/alternative.h \
    $(wildcard include/config/MODULES) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/asm/atomic_lse.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/atomic/atomic-arch-fallback.h \
    $(wildcard include/config/GENERIC_ATOMIC64) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/atomic/atomic-long.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/atomic/atomic-instrumented.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/instrumented.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/kmsan-checks.h \
    $(wildcard include/config/KMSAN) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/bitops/instrumented-atomic.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/bitops/lock.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/bitops/instrumented-lock.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/bitops/non-atomic.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/bitops/non-instrumented-non-atomic.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/bitops/le.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/bitops/ext2-atomic-setbit.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/hex.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/kstrtox.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/log2.h \
    $(wildcard include/config/ARCH_HAS_ILOG2_U32) \
    $(wildcard include/config/ARCH_HAS_ILOG2_U64) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/math.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/generated/asm/div64.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/div64.h \
    $(wildcard include/config/CC_OPTIMIZE_FOR_PERFORMANCE) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/minmax.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/sprintf.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/static_call_types.h \
    $(wildcard include/config/HAVE_STATIC_CALL) \
    $(wildcard include/config/HAVE_STATIC_CALL_INLINE) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/trace_printk.h \
    $(wildcard include/config/TRACING) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/instruction_pointer.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/util_macros.h \
    $(wildcard include/config/FOO_SUSPEND) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/wordpart.h \

src/panic.o: $(deps_src/panic.o)

$(deps_src/panic.o):
