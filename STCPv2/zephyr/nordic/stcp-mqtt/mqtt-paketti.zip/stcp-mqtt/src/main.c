#include <zephyr/kernel.h>
#include <zephyr/logging/log.h>

#include <modem/nrf_modem_lib.h>
#include <modem/lte_lc.h>

LOG_MODULE_REGISTER(main, LOG_LEVEL_DBG);

int main(void)
{
    int ret;

    LOG_INF("STCP2 MQTT proxy starting");

    ret = nrf_modem_lib_init();
    if (ret < 0) {
        LOG_ERR("nrf_modem_lib_init failed: %d", ret);
        return ret;
    }

    LOG_INF("nRF modem library initialized");
    ret = stcp_lte_init_and_connect();
    if (ret < 0) {
        LOG_ERR("STCP LTE initialization failed: %d", ret);
        return ret;
    }

    LOG_INF("LTE connected");
s
    /* STCP socket + MQTT tästä eteenpäin */

    return 0;
}