#!/usr/bin/env bash
set -Eeuo pipefail

log() { echo "[INFO] $*"; }
die() { echo "[FAIL] $*" >&2; exit 1; }

[[ "$(id -u)" == "0" ]] || die "Run this installer as root: sudo ./install.sh"

PKG_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ROOTFS="$PKG_DIR/rootfs"
BOOT_PAYLOAD="$PKG_DIR/boot-payload"
KREL="$(cat "$PKG_DIR/KERNEL_RELEASE")"
TARGET="$(cat "$PKG_DIR/TARGET")"
TARGET_DTB="$(cat "$PKG_DIR/TARGET_DTB")"
PREFIX="stcp-${KREL}"

if [[ -d /boot/firmware && -f /boot/firmware/config.txt ]]; then
    BOOT_DIR="/boot/firmware"
elif [[ -f /boot/config.txt ]]; then
    BOOT_DIR="/boot"
else
    die "Raspberry Pi boot config was not found"
fi

CONFIG_TXT="$BOOT_DIR/config.txt"
CMDLINE_TXT="$BOOT_DIR/cmdline.txt"
PREFIX_DIR="$BOOT_DIR/$PREFIX"
MODULE_SRC="$ROOTFS/lib/modules/$KREL"
MODULE_DST="/lib/modules/$KREL"

[[ -d "$MODULE_SRC" ]] || die "Packaged modules missing: $MODULE_SRC"
[[ -f "$BOOT_PAYLOAD/Image" ]] || die "Packaged kernel Image missing"
[[ -f "$BOOT_PAYLOAD/System.map" ]] || die "Packaged System.map missing"
[[ -f "$BOOT_PAYLOAD/config" ]] || die "Packaged kernel config missing"
[[ -d "$BOOT_PAYLOAD/dtbs" ]] || die "Packaged DTBs missing"
[[ -d "$BOOT_PAYLOAD/overlays" ]] || die "Overlay payload directory missing"
[[ -f "$CMDLINE_TXT" ]] || die "Missing Raspberry Pi cmdline.txt: $CMDLINE_TXT"

for cmd in depmod update-initramfs awk sed find install cp sync; do
    command -v "$cmd" >/dev/null 2>&1 || \
        [[ -x "/usr/sbin/$cmd" ]] || die "Required target command missing: $cmd"
done

DEPMOD="$(command -v depmod 2>/dev/null || echo /usr/sbin/depmod)"
UPDATE_INITRAMFS="$(command -v update-initramfs 2>/dev/null || echo /usr/sbin/update-initramfs)"

STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/root/stcp-kernel-backup-${KREL}-${STAMP}"
mkdir -p "$BACKUP"

log "Backing up boot configuration and conflicting files to $BACKUP"
cp -a "$CONFIG_TXT" "$BACKUP/config.txt"
cp -a "$CMDLINE_TXT" "$BACKUP/cmdline.txt"
[[ -d "$PREFIX_DIR" ]] && cp -a "$PREFIX_DIR" "$BACKUP/"
[[ -d "$MODULE_DST" ]] && cp -a "$MODULE_DST" "$BACKUP/modules-$KREL"
for f in "/boot/vmlinuz-$KREL" "/boot/System.map-$KREL" \
         "/boot/config-$KREL" "/boot/initrd.img-$KREL"; do
    [[ -e "$f" ]] && cp -a "$f" "$BACKUP/"
done

log "Installing kernel modules"
rm -rf "$MODULE_DST"
mkdir -p "$MODULE_DST"
cp -a "$MODULE_SRC/." "$MODULE_DST/"
"$DEPMOD" -a "$KREL"

log "Installing standard /boot kernel metadata"
install -m0644 "$BOOT_PAYLOAD/Image" "/boot/vmlinuz-$KREL"
install -m0644 "$BOOT_PAYLOAD/System.map" "/boot/System.map-$KREL"
install -m0644 "$BOOT_PAYLOAD/config" "/boot/config-$KREL"

log "Generating target-specific initramfs"
rm -f "/boot/initrd.img-$KREL"
"$UPDATE_INITRAMFS" -c -k "$KREL"
[[ -s "/boot/initrd.img-$KREL" ]] || die "initramfs generation failed"

log "Installing isolated Raspberry Pi firmware boot set"
rm -rf "$PREFIX_DIR"
mkdir -p "$PREFIX_DIR/overlays"
install -m0644 "$BOOT_PAYLOAD/Image" "$PREFIX_DIR/kernel8.img"
install -m0644 "/boot/initrd.img-$KREL" "$PREFIX_DIR/initramfs8"
install -m0644 "$CMDLINE_TXT" "$PREFIX_DIR/cmdline.txt"

# Raspberry Pi firmware expects board DTBs at the prefix root. Copy every
# packaged board DTB there, regardless of whether it came from broadcom/.
while IFS= read -r -d '' dtb; do
    install -m0644 "$dtb" "$PREFIX_DIR/$(basename "$dtb")"
done < <(find "$BOOT_PAYLOAD/dtbs" -type f -name '*.dtb' -print0)

# os_prefix also affects dtoverlay lookups. Seed the isolated prefix with
# the overlays already known to boot on this Raspberry Pi, then overwrite them
# with package-built overlays when the source tree supplied any.
if [[ -d "$BOOT_DIR/overlays" ]]; then
    cp -a "$BOOT_DIR/overlays/." "$PREFIX_DIR/overlays/"
fi
if find "$BOOT_PAYLOAD/overlays" -maxdepth 1 -type f -print -quit | grep -q .; then
    cp -a "$BOOT_PAYLOAD/overlays/." "$PREFIX_DIR/overlays/"
fi

[[ -s "$PREFIX_DIR/kernel8.img" ]] || die "Installed kernel is empty"
[[ -s "$PREFIX_DIR/initramfs8" ]] || die "Installed initramfs is empty"
[[ -f "$PREFIX_DIR/$TARGET_DTB" ]] || die "Installed target DTB missing: $TARGET_DTB"
[[ -n "$(find "$PREFIX_DIR/overlays" -maxdepth 1 -type f -name '*.dtbo' -print -quit)" ]] || \
    die "No overlays available: neither package nor $BOOT_DIR/overlays contained .dtbo files"

log "Activating the new boot set in config.txt"
TMP_CONFIG="$(mktemp)"
awk '
    /^# BEGIN STCP KERNEL$/ { skip=1; next }
    /^# END STCP KERNEL$/   { skip=0; next }
    !skip { print }
' "$CONFIG_TXT" > "$TMP_CONFIG"

{
    cat <<CFG
# BEGIN STCP KERNEL
[all]
arm_64bit=1
os_prefix=${PREFIX}/
kernel=kernel8.img
auto_initramfs=1
# END STCP KERNEL

CFG
    cat "$TMP_CONFIG"
} > "$CONFIG_TXT"
rm -f "$TMP_CONFIG"

ROLLBACK="/usr/local/sbin/rollback-stcp-kernel-${KREL}.sh"
cat > "$ROLLBACK" <<ROLLBACK_SCRIPT
#!/usr/bin/env bash
set -Eeuo pipefail
[[ "\$(id -u)" == "0" ]] || { echo "Run as root" >&2; exit 1; }
cp -a "$BACKUP/config.txt" "$CONFIG_TXT"
rm -rf "$PREFIX_DIR"
if [[ -d "$BACKUP/$(basename "$PREFIX_DIR")" ]]; then
    cp -a "$BACKUP/$(basename "$PREFIX_DIR")" "$PREFIX_DIR"
fi
rm -rf "$MODULE_DST"
if [[ -d "$BACKUP/modules-$KREL" ]]; then
    cp -a "$BACKUP/modules-$KREL" "$MODULE_DST"
fi
"$DEPMOD" -a "$KREL" || true
sync
echo "Restored the previous boot configuration from $BACKUP"
echo "Reboot when ready."
ROLLBACK_SCRIPT
chmod 0755 "$ROLLBACK"

sync

cat <<SUMMARY

Installation completed successfully.

Kernel release:  $KREL
Target:          $TARGET
Boot directory:  $BOOT_DIR
Boot prefix:     $PREFIX_DIR
Modules:         $MODULE_DST
Initramfs:       /boot/initrd.img-$KREL
Backup:          $BACKUP
Rollback:        sudo $ROLLBACK

Before reboot, verify with:
  ls -lh "$PREFIX_DIR/kernel8.img" "$PREFIX_DIR/initramfs8"
  ls -lh "$PREFIX_DIR/$TARGET_DTB"
  grep -A6 -B1 'BEGIN STCP KERNEL' "$CONFIG_TXT"

Then reboot:
  sudo reboot
SUMMARY
