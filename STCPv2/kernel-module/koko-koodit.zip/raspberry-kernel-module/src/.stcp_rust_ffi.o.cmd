savedcmd_src/stcp_rust_ffi.o := aarch64-linux-gnu-gcc -Wp,-MMD,src/.stcp_rust_ffi.o.d -nostdinc -I/home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include -I/home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/generated -I/home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include -I/home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include -I/home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/uapi -I/home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/generated/uapi -I/home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi -I/home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/generated/uapi -include /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/compiler-version.h -include /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/kconfig.h -include /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/compiler_types.h -D__KERNEL__ -mlittle-endian -DCC_USING_PATCHABLE_FUNCTION_ENTRY -DKASAN_SHADOW_SCALE_SHIFT= -std=gnu11 -fshort-wchar -funsigned-char -fno-common -fno-PIE -fno-strict-aliasing -mgeneral-regs-only -DCONFIG_CC_HAS_K_CONSTRAINT=1 -Wno-psabi -mabi=lp64 -fno-asynchronous-unwind-tables -fno-unwind-tables -mbranch-protection=pac-ret -Wa,-march=armv8.5-a -DARM64_ASM_ARCH='"armv8.5-a"' -DKASAN_SHADOW_SCALE_SHIFT= -fno-delete-null-pointer-checks -O2 -fno-allow-store-data-races -fstack-protector-strong -fno-omit-frame-pointer -fno-optimize-sibling-calls -ftrivial-auto-var-init=zero -fno-stack-clash-protection -fpatchable-function-entry=4,2 -fmin-function-alignment=8 -fstrict-flex-arrays=3 -fno-strict-overflow -fno-stack-check -fconserve-stack -fno-builtin-wcslen -Wall -Wextra -Wundef -Werror=implicit-function-declaration -Werror=implicit-int -Werror=return-type -Werror=strict-prototypes -Wno-format-security -Wno-trigraphs -Wno-frame-address -Wno-address-of-packed-member -Wmissing-declarations -Wmissing-prototypes -Wframe-larger-than=2048 -Wno-main -Wno-dangling-pointer -Wvla-larger-than=1 -Wno-pointer-sign -Wcast-function-type -Wno-array-bounds -Wno-stringop-overflow -Wno-alloc-size-larger-than -Wimplicit-fallthrough=5 -Werror=date-time -Werror=incompatible-pointer-types -Werror=designated-init -Wenum-conversion -Wunused -Wno-unused-but-set-variable -Wno-unused-const-variable -Wno-packed-not-aligned -Wno-format-overflow -Wno-format-truncation -Wno-stringop-truncation -Wno-override-init -Wno-missing-field-initializers -Wno-type-limits -Wno-shift-negative-value -Wno-maybe-uninitialized -Wno-sign-compare -Wno-unused-parameter -mstack-protector-guard=sysreg -mstack-protector-guard-reg=sp_el0 -mstack-protector-guard-offset=1504 -I././include  -DMODULE  -DKBUILD_BASENAME='"stcp_rust_ffi"' -DKBUILD_MODNAME='"stcp"' -D__KBUILD_MODNAME=kmod_stcp -c -o src/stcp_rust_ffi.o src/stcp_rust_ffi.c  

source_src/stcp_rust_ffi.o := src/stcp_rust_ffi.c

deps_src/stcp_rust_ffi.o := \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/compiler-version.h \
    $(wildcard include/config/CC_VERSION_TEXT) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/kconfig.h \
    $(wildcard include/config/CPU_BIG_ENDIAN) \
    $(wildcard include/config/BOOGER) \
    $(wildcard include/config/FOO) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/compiler_types.h \
    $(wildcard include/config/DEBUG_INFO_BTF) \
    $(wildcard include/config/PAHOLE_HAS_BTF_TAG) \
    $(wildcard include/config/FUNCTION_ALIGNMENT) \
    $(wildcard include/config/CC_HAS_SANE_FUNCTION_ALIGNMENT) \
    $(wildcard include/config/X86_64) \
    $(wildcard include/config/ARM64) \
    $(wildcard include/config/LD_DEAD_CODE_DATA_ELIMINATION) \
    $(wildcard include/config/LTO_CLANG) \
    $(wildcard include/config/HAVE_ARCH_COMPILER_H) \
    $(wildcard include/config/KCSAN) \
    $(wildcard include/config/CC_HAS_ASSUME) \
    $(wildcard include/config/CC_HAS_COUNTED_BY) \
    $(wildcard include/config/CC_HAS_MULTIDIMENSIONAL_NONSTRING) \
    $(wildcard include/config/UBSAN_INTEGER_WRAP) \
    $(wildcard include/config/CFI) \
    $(wildcard include/config/ARCH_USES_CFI_GENERIC_LLVM_PASS) \
    $(wildcard include/config/CC_HAS_ASM_INLINE) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/compiler_attributes.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/compiler-gcc.h \
    $(wildcard include/config/ARCH_USE_BUILTIN_BSWAP) \
    $(wildcard include/config/SHADOW_CALL_STACK) \
    $(wildcard include/config/KCOV) \
    $(wildcard include/config/CC_HAS_TYPEOF_UNQUAL) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/asm/compiler.h \
    $(wildcard include/config/ARM64_PTR_AUTH_KERNEL) \
    $(wildcard include/config/ARM64_PTR_AUTH) \
    $(wildcard include/config/BUILTIN_RETURN_ADDRESS_STRIPS_PAC) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/stcp_rust_ffi.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/types.h \
    $(wildcard include/config/HAVE_UID16) \
    $(wildcard include/config/UID16) \
    $(wildcard include/config/ARCH_DMA_ADDR_T_64BIT) \
    $(wildcard include/config/PHYS_ADDR_T_64BIT) \
    $(wildcard include/config/64BIT) \
    $(wildcard include/config/ARCH_32BIT_USTAT_F_TINODE) \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/linux/types.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/generated/uapi/asm/types.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/asm-generic/types.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/int-ll64.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/asm-generic/int-ll64.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/uapi/asm/bitsperlong.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/asm-generic/bitsperlong.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/asm-generic/bitsperlong.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/linux/posix_types.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/linux/stddef.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/linux/stddef.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/arch/arm64/include/uapi/asm/posix_types.h \
  /home/pomo/git/STCP/STCPv2/kernel-module/raspberry-kernel-sources/include/uapi/asm-generic/posix_types.h \

src/stcp_rust_ffi.o: $(deps_src/stcp_rust_ffi.o)

$(deps_src/stcp_rust_ffi.o):
