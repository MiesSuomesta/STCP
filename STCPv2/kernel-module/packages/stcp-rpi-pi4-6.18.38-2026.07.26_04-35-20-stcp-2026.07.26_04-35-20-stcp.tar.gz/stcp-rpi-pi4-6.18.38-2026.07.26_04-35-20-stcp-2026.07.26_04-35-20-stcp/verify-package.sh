#!/usr/bin/env bash
set -Euo pipefail
PKG_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
KREL="$(cat "$PKG_DIR/KERNEL_RELEASE")"
TARGET_DTB="$(cat "$PKG_DIR/TARGET_DTB")"
[[ -s "$PKG_DIR/boot-payload/Image" ]]
[[ -s "$PKG_DIR/boot-payload/System.map" ]]
[[ -s "$PKG_DIR/boot-payload/config" ]]
[[ -f "$PKG_DIR/rootfs/lib/modules/$KREL/extra/stcp.ko" ]]
find "$PKG_DIR/boot-payload/dtbs" -type f -name "$TARGET_DTB" -print -quit | grep -q .
echo "Package contents OK for kernel $KREL"
