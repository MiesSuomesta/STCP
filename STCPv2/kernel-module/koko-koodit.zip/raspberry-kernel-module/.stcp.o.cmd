savedcmd_stcp.o := aarch64-linux-gnu-ld -EL  -maarch64elf -z noexecstack --no-warn-rwx-segments   -r -o stcp.o @stcp.mod 
