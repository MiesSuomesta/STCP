#!/usr/bin/env bash
set -Eeuo pipefail
[[ "$(id -u)" == 0 ]] || { echo "Run: sudo ./install.sh" >&2; exit 1; }
PKG_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ROOTFS="$PKG_DIR/rootfs"
KREL="$(cat "$PKG_DIR/KERNEL_RELEASE")"
KERNEL_FILE="kernel-stcp-${KREL}.img"
if [[ -d /boot/firmware ]]; then BOOT_DIR=/boot/firmware; else BOOT_DIR=/boot; fi
CONFIG="$BOOT_DIR/config.txt"
[[ -f "$CONFIG" ]] || { echo "Missing $CONFIG" >&2; exit 1; }
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/root/stcp-kernel-backup-$STAMP"
mkdir -p "$BACKUP"
cp -a "$CONFIG" "$BACKUP/config.txt"
rm -rf "/lib/modules/$KREL"
mkdir -p "/lib/modules/$KREL"
cp -a "$ROOTFS/lib/modules/$KREL/." "/lib/modules/$KREL/"
install -m0644 "$ROOTFS/boot/firmware/$KERNEL_FILE" "$BOOT_DIR/$KERNEL_FILE"
sed -i '/^# BEGIN STCP KERNEL$/,/^# END STCP KERNEL$/d' "$CONFIG"
cat >> "$CONFIG" <<CFG

# BEGIN STCP KERNEL
[all]
arm_64bit=1
kernel=$KERNEL_FILE
# END STCP KERNEL
CFG
DEPMOD="$(command -v depmod 2>/dev/null || true)"; [[ -n "$DEPMOD" ]] || DEPMOD=/usr/sbin/depmod
"$DEPMOD" -a "$KREL"
echo "Installed $KREL. DTBs and overlays were not modified."
echo "Reboot: sudo reboot"
echo "Rollback: restore $BACKUP/config.txt"
