cmd_src/rust_core.o := aarch64-linux-gnu-ld -r <Rust objects> -o src/rust_core.o
